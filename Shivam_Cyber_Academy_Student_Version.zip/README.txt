SHIVAM CYBER ACADEMY — STUDENT DEMO

HOW TO RUN IN REPLIT
1. Create a new HTML/CSS/JS project.
2. Upload index.html, style.css, app.js and manifest.json.
3. Open the web preview.

INCLUDED
- Mobile-friendly cyber academy home page
- Hindi/English text toggle
- Cyber safety, networking and ethical hacking introduction lessons
- Demo student profile (name only)
- Learning progress saved locally in the same browser
- Cyber safety quiz
- Course certificate preview with selected course and learner name
- Print / Save as PDF option

IMPORTANT LIMITATIONS
- Student profile is a local demo, not a real login system.
- Profiles and progress do not sync across devices or students.
- No password is collected or stored.
- Certificate is a sample completion preview, not an accredited qualification.
- QR-based independent verification and real multi-user accounts require a secure backend and server-side records.
