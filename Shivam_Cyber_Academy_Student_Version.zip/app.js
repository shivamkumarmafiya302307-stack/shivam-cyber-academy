const lessons = {
  safety: ["Cyber Safety", "Use a unique password for each important account, turn on two-step verification, never share OTPs, and verify links before opening them. If a message pressures you to act quickly, pause and check through the official app or website."],
  network: ["Networking Basics", "A network connects devices so they can communicate. An IP address helps identify a device on a network, while DNS helps translate website names into network addresses. Start by learning these concepts before trying any tools."],
  ethics: ["Ethical Hacking Intro", "Ethical security testing requires clear written permission, a defined scope and responsible reporting. Practice only in purpose-built training labs or on systems you own. Never access another person's account or device."]
};
const dialog = document.getElementById("lessonDialog");
document.querySelectorAll(".learn-btn").forEach(btn => btn.addEventListener("click", () => {
  const lesson = lessons[btn.dataset.topic];
  document.getElementById("lessonTitle").textContent = lesson[0];
  document.getElementById("lessonText").textContent = lesson[1];
  dialog.showModal();
}));
document.getElementById("closeDialog").addEventListener("click", () => dialog.close());
document.getElementById("doneBtn").addEventListener("click", () => dialog.close());
let hindi = false;
document.getElementById("langBtn").addEventListener("click", () => {
  hindi = !hindi;
  document.querySelectorAll("[data-en]").forEach(el => { el.innerHTML = hindi ? el.dataset.hi : el.dataset.en; });
  document.getElementById("langBtn").textContent = hindi ? "EN / हिं" : "हिं / EN";
});


document.getElementById("generateCertificate").addEventListener("click", () => {
  const name = document.getElementById("studentName").value.trim();
  if (!name) {
    alert("Please enter the student's name.");
    return;
  }
  const course = document.getElementById("courseName").value;
  const id = "SCA-" + new Date().getFullYear() + "-" + Math.random().toString(36).slice(2, 8).toUpperCase();
  document.getElementById("certStudent").textContent = name;
  document.getElementById("certCourse").textContent = course;
  document.getElementById("certId").textContent = id;
  document.getElementById("certificateResult").hidden = false;
  document.getElementById("certificateResult").scrollIntoView({behavior:"smooth", block:"start"});
});
document.getElementById("printCertificate").addEventListener("click", () => window.print());


// Demo student profile: stores only a display name in this browser.
// This is not production authentication and does not sync between devices.
const profileKey = "sca_demo_student_name";
const completedKey = "sca_demo_completed_lessons";
function updateStudentPanel() {
  const name = localStorage.getItem(profileKey);
  document.getElementById("signupPanel").hidden = !!name;
  document.getElementById("profilePanel").hidden = !name;
  if (name) document.getElementById("welcomeName").textContent = name;
  const completed = JSON.parse(localStorage.getItem(completedKey) || "[]");
  document.getElementById("progressBar").style.width = (completed.length / 3 * 100) + "%";
  document.getElementById("progressText").textContent = completed.length + " of 3 lessons completed";
}
document.getElementById("saveProfile").addEventListener("click", () => {
  const name = document.getElementById("profileName").value.trim();
  if (!name) { alert("Please enter your name."); return; }
  localStorage.setItem(profileKey, name);
  updateStudentPanel();
});
document.getElementById("resetProfile").addEventListener("click", () => {
  localStorage.removeItem(profileKey);
  localStorage.removeItem(completedKey);
  updateStudentPanel();
});
updateStudentPanel();

// Mark a lesson as completed when its mini-lesson is opened.
const originalLessonHandler = document.querySelectorAll(".learn-btn");
originalLessonHandler.forEach(btn => {
  if (btn.dataset.topic) {
    btn.addEventListener("click", () => {
      const completed = JSON.parse(localStorage.getItem(completedKey) || "[]");
      if (!completed.includes(btn.dataset.topic)) completed.push(btn.dataset.topic);
      localStorage.setItem(completedKey, JSON.stringify(completed));
      updateStudentPanel();
    });
  }
});

document.getElementById("submitQuiz").addEventListener("click", () => {
  const answers = {q1:"b", q2:"b", q3:"a"};
  let score = 0;
  for (const [question, correct] of Object.entries(answers)) {
    const selected = document.querySelector('input[name="' + question + '"]:checked');
    if (!selected) {
      document.getElementById("quizResult").textContent = "Please answer all 3 questions first.";
      return;
    }
    if (selected.value === correct) score++;
  }
  document.getElementById("quizResult").textContent =
    "You scored " + score + "/3. " + (score === 3 ? "Excellent work!" : "Review the lessons and try again.");
});
